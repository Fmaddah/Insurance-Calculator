import csv
# in the dictionary we add a place to store the name and when the user asks for the list it print the saved list.
#when there isnt a list print no excisting file. 
def ScoreList():
    try:
        with open('Storage.csv', 'r') as file:
            
            for row in file:
                print(row)
    except FileNotFoundError:
        print("No scores have been allocated.")

#ask for a user input if the input is found in storage print, if print a error.
def search_specific_username():
    user = input('Pick a user ')

    with open('Storage.csv') as file:
        if user in file:
            print (f"{user}'s score in .. is ..")
        else:
            print("username not found")



def addToList(Name, Score):
    Name = Name.strip() # Remove leading and trailing whitespaces
    Score = Score.strip() # Remove leading and trailing whitespaces
    # writer is equal to storage
    with open('Storage.csv', 'a', newline='') as file:
        writer = csv.writer(file)
        writer.writerow([Name, Score])# ask for username and score from input
    print(f"{Score} {Name}(s) added to the score list.")# print the new scores added.

def main():
    print("Welcome to High Score Manager!")
# ask the user for one of the 4 choices 
    while True:
        print("\nScores:")
        print("1. list all scores")
        print("2. Add Scores")
        print("3. Find specific username")
        print("4. Exit")

        choice = input("Enter your choice (1/2/3/4): ")

        if choice == '1':
            ScoreList()# from choice 1 refer to scoreList
        elif choice == '2':
            Name = input("Enter the Username: ")# ask for what inputs they want then print it
            Score = input("Enter the Score: ")
            addToList(Name, Score)
        elif choice == '3':
            search_specific_username()# refer to search_specific_username

        elif choice == '4':
            print("Exiting")#exit 
            break
        else:
            print("Invalid. Please enter 1, 2, 3, 4")#if 1-4 isnt chosen print invalid
if __name__ == "__main__":
    main()