welcome = print("\nWelcome to the interest calculater\n\n")
# we welcome the readers.

# In the next three While True we ask for the input and check if the input that is provided is acceptable 
while True:
    try:
        deposit = float(input("Enter the amount you want to deposit:$"))

        if deposit <= 0:
            print("Please enter positive numbers")
        else:
            break
    except ValueError:
        print("Please enter positive numbers")
        

while True:
    try:
        interest = float(input("Enter the yearly interest rate (%)"))
        if interest<= 0:
            print("Please enter positive numbers")
        else:
            break
    except ValueError:
        print("Please enter positive numbers")

while True:
    try:
        numYears = int(input("Input the number of years: "))
        if numYears<= 0:
            print("Please enter positive numbers")
        else:
            break
    except ValueError:
        print("Please input a positive integer")
        
# Here we calculate the interest rate yearly and print the amount yearly.
total = deposit 
for year in range(1, numYears+1):
    interest = (total * interest)/100
    total += interest
    print(f"Your total will be ${total:.2f} in year {year} and your interest amount will be ${interest:.2f}")
# We print the total amount of money by the end of the years
print(f"\nIn the end you will have ${total:.2f} from {year} years")